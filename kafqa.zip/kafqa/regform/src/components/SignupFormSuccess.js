import React from "react";
import "../App.css";


const SignupFormSuccess = () => {
    return(
        <div className="container">
            <div className="app-wraper">
                <h1 className="form-success">Hello World</h1>
            </div>

        </div>
    )
}

export default SignupFormSuccess